jQuery(function( $ ){

	$('.posts-archive .content .entry, .category-index .featured-content .entry').matchHeight();

});